A Low Power 6T SRAM cell using Supply Feedback Technique using CMOS

The downscaling of CMOS technology creates critical issues like power dissipation and stability in (SRAM). Which eventually degrades the performance of the SRAM cell. Hence to address the issue of data stability and power dissipation, this paper proposed a new
(6T) SRAM cell to increases the write ability and reduces the static power consumption or dissipation using
supply feedback transistor. Whereas the HSNM, read delay, and static power consumption or dissipation
The newly designed 6T SRAM cell has been calibrated in the eSim and sky130.

Static Noise Margin (SNM) Analysis
Static noise margin (SNM) is a functional metric to analyse the stability of SRAM cell. The graphical representation of SNM is through the largest square diagonal between the voltage transfer characteristics (VTC) of inverters. It determines the capability to retain the information that is stored. SNM measures the SRAM stability and it defines the maximum noise margin that a cell can store the data without losing the information.

The user of this IP has to install Ngspice for Circuit simulation and esim for schematic.

First step:
1. Design schematic using esim
2. Electrical check of design.
3. Save netlist
4. Edit netlist with Sky130
5.Simualtion using ngspice
6. Check waveform

In my design I simulate the Write and Read operation of sram and Write static noise margin(WSNM) and Read static noise margin(RSNM) and compare with my reference circuit.
Static random access memory (SRAM) is one of the most important building blocks in digital circuits which occupies about 90% of the modern chip area. With the technology as well as supply voltage shrinking down, it has become extremely challenging to design SRAM due to less noise margin and hence poor stability. So with scaled technology, it is very difficult to meet three constraints of SRAM: area, power consumption, and stability. Therefore, scaling in SRAM size has not significantly reduced as compared to other chip components, 6T (seven transistor) SRAM cell is proposed and compared with the standard 6T SRAM cell on the basis of read delay, write delay, leakage power consumption and Static Noise Margin (SNM) (during hold, read and write). This proposed cell uses single bitline for read and write operation. Thus it also improves the access time of the cell. 


The downscaling of CMOS technology creates critical issues like power dissipation and stability in (SRAM). Which eventually degrades the performance of the SRAM cell. Hence to address the issue of data stability and power dissipation, this paper proposed a new (7T) SRAM cell to increases the write ability and reduces the static power consumption or dissipation using supply feedback transistor. Whereas the HSNM, read delay, and static power consumption or dissipation of proposed 7T is decreased by 1.08x, 1.3x, and 1.5x respectively in comparison to basic 6T SRAM cell at the same power supply. The newly designed 7T SRAM cell has been calibrated in the Esim and sky130.


Random Access Memory is accessed by an address but its latency is independent of the address. Static Random Access Memory (SRAM) is the volatile kind of memory i.e., it retains its data as long as the power supply is given while the Dynamic Random Access Memory (DRAM) should be periodically refreshed. An SRAM cell is used to store single bit information in the form of either '0' or '1'. SRAM is used in cache memory. From the last more than five decades the size of the CMOS devices is being scaled down to accommodate maximum memory on Soc. More memory that means more information can be stored, that makes the system faster. The low power operation of system can be achieved by lowering the leakage current which can reduce the leakage power consumption. For this purpose supply voltages and threshold voltages is being scaled down but it affects the stability of SRAM cells that is the noise margin is reduced. Shrinking of technology also degrades the stability.

There are two key features to SRAM - Static random Access Memory, and these set it out against other types of memory that are available:
1.The data is held statically: This means that the data is held in the semiconductor memory without the need to be refreshed as long as the power is applied to the memory.
2. SRAM is a form of random access memory: A random access memory is one in which the locations in the semiconductor memory can be written to or read from in any order, regardless of the last memory location that was accessed. The circuit for an individual SRAM memory cell comprises typically two or four transistors. In this format the circuit has two stable states, and these equate to the logical "0" and "1" states. These additional transistors are used for functions such as implementing additional ports in a register file, etc for the SRAM memory. 
This section describes 6T SRAM cell design. A comparative study of a novel 6T cell design with the conventional design shows a performance improvement of novel 6T-SRAM designs. Using CMOS technology the design is implemented in 130nm.The main aim of this 6T SRAM cell is to reduce the consumption of leakage power and improve the stability of the memory cell in normal region of operation. Some design architecture used CMOS transistor operation in sub-threshold region for reducing power.

This project proposes a novel 6T SRAM cell. In the proposed design the read and write operation have been performed separately using read and write port to enhance
the data stability. Furthermore, the supply feedback transistor has been used between data storing node and cell power supply in order to increase the write ability of the SRAM cell.

The main aim of this 6T SRAM cell is to reduce the consumption of leakage power and improve the stability of the memory cell in normal region of operation. Some design architecture used CMOS transistor operation in sub-threshold region  for reducing power. A modified 8-T design architecture is proposed for low power and low voltage circuits.
The proposed 6T SRAM cell using supply feedback concept, which comprises of 4 NMOS transistors and three PMOS transistors. Transistor PM1, PM2, NM1, and NM2 forms the latch of SRAM cell where the data has been stored, whereas NM3 acts as an access transistor during the write operation which is activated by word line (WL) signal and NM4 acts as an access transistor during read mode which basically used to separate the RBL from storing nodes Qb and Q of SRAM cell for providing disturb free read operation. The transistor PM3 acts as a feedback transistor which is connected between the power supply and storing node Q. When feedback transistor PM3 is ON state, the voltage at the drain of PM3 is slightly lower than the supply voltage. This eventually saves power as the reduced supply voltage is available to the latch. The bitline (BL) is an input line of a cell during write operation whereas RBL is input or output line during the read operation. This cell has single ended read and write operations. To enhance read stability and write ability, two different techniques are considered. M7 acts as the isolation transistor that isolates the left storage node from the voltage enhancement on the right storage node during the read operation.
The several modes of operation of the proposed cell are given as:

Read Mode Operation
In this operation, WL and BL are tied to Vdd and ground respectively, while RBL is initially charged to Vdd. In read ‘0’ mode (assuming node Q and Qb of the proposed
design initially stored logic ‘0’ and ‘1’ respectively) the PMOS transistor PM1 goes in OFF state, PM2 transistor in ON state, NM1 transistor in ON, and NM2 transistor in OFF
state. The transistor NM4 (as gated by node Qb) would be in ON state and forms a conducting path between RBL and ground RBL then starts to discharge towards the ground potential and hence the process of reading ‘0’ has been done. Whereas for read ‘1’ operation, the logic ‘1’ must be stored at node Q and ‘0’ at Qb, which tries the transistor NM4 to turn OFF. As a result, it does not form the path between RBL to ground. The RBL thereby retains at its pre-charged value (Vdd)

Write Mode Operation
The write mode of operation begins by connected the WL to Vdd that subsequently switches ON the access transistor NM3. The bitline is driven to the data level which has to be written. A conducting path has been formed between input bitline and node Q through access transistor NM3. In this mode, the RBL is tied to the ground. During the operation of write ‘1’ at node Q, (assume initially logic ‘0’ and ‘1’ are stored at node Q and Qb respectively, BL is driven to Vdd, then the strength of access transistor NM3
is high. As WL is activated, the voltage at storing node Qb is low enough due to feedback transistor PM3 which initiated the internal positive feedback and flip the data of storing nodes. Similarly for writing ‘0’ operation, the BL is driven to the ground. Initially, the feedback transistor PM3 is in OFF state and provides a pull-up current which is not matched with high discharge current through transistor NM3.
In comparison with the conventional 6T cell, the write operation of the proposed cell has two major differences. The first one is that it is single-ended. The second difference of the write operation of this cell and the conventional 6T is that this cell uses a virtual ground to weaken one of the back-to-back inverters and reduce the strength of the positive feedback. Consequently, writing a new data on this cell is done easily. To prevent using extra voltage rails in the SRAM block, we use the circuit suggested in to create two different voltages according to the cell operation. While in the write operation, the virtual ground node is connected to the source of a PMOS transistor which is poor at pulling a node to ground, so the voltage of this node increases and the write operation is done easily.

RESULTS AND DISCUSSION
The performance of the proposed design is estimated by
designing and simulating the circuit in esim and ngspice with sky130.The simulated
results and discussion of several performance parameters are
as follows: The transient waveform during a write operation is presented.

Read Stability
The read static noise margin RSNM value represents the read stability of the SRAM cell which is examined by maximum DC noise voltage presents at the input of cross-coupled inverter pairs which unchanged the cell state without failing any data. The value of the RSNM during read operation has been achieved from the butterfly curve (plot of dc curve of back to back connected CMOS inverter) by catching the length of a side in the square that is built up in two segment of butterfly curve. The method of finding the read stability from the  butterfly curve is observed.
To measure the read static noise margin (RSNM), two conventional methods exist. One of them is drawing the butterfly curves and trying to fit the largest square in it . The side length of this square is SNM. The other way to measure this parameter is injection of two noise sources with opposite polarities on storage nodes. The maximum value of the noise that doesn't change the stored data is the read static noise margin

Write Stability
The write ability of any SRAM cell during a write operation is described by write static noise margin (WSNM).
For write ability measurements, write noise margin (WNM) is used as a metric. The WNM is defined as the difference of the maximum bitline voltage (which typically should be ground) that is able to flip the cell's stored data (write trip point) and VDD.

Conclusion:
This project proposed a novel 6T SRAM cell for increasing the write ability and decreasing the static power consumption or dissipation using a supply feedback transistor. Furthermore, the read stability also increased using separate read port. Whereas hold stability of the proposed design has been slightly decreased due to a reduction in the supply voltage. The proposed 7T SRAM cell is simulated in the esim and ngspice environment using a 130nm CMOS technology node. This has been examined that the RSNM, WSNM, and write delay of proposed 6T is increased by 1.8x, 1.10x, and 1.16x respectively when a comparison is done with conventional 6T SRAM cell at the same cell power supply. Whereas the HSNM, read delay, and static power consumption or dissipation of proposed 6T is decreased by 1.08x, 1.3x, and 1.5x respectively in comparison with conventional 6T SRAM cell at the same cell power supply.
